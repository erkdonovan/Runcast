I built this web app to help me figure out what the weather is and what I need to wear for running. 

The clothing choices are based on my own preference.

<img src="assets/screenshot.png" alt="Screen shot of app">